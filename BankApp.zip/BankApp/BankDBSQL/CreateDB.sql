use BankDB;
create table osoby(
id_osob int IDENTITY(1,1) primary key not null,
jmeno nvarchar(30) not null,
prijmeni nvarchar(30) not null,
dat_naroz date not null,
pohlavi varchar(10) NOT NULL CHECK (pohlavi IN('male', 'female')), --ENUM parametr
tel_cis int not null,
email nvarchar(50) not null,
rodne_cis int unique not null,
cislo_op int unique not null,
adresa nvarchar(150),
);

create table ucty(
id_uct int IDENTITY(1,1) primary key not null,
vlastnik int foreign key (vlastnik) references osoby(id_osob) on delete cascade,
username nvarchar(30) unique not null,
heslo nvarchar(30) not null,
typ_uctu nvarchar(30) not null check (typ_uctu in('banker','zakaznik','admin')),
balance decimal not null,
cislo_uctu nvarchar(14),
);

create table banky(
id_banky int IDENTITY(1,1) primary key not null,
nazev nvarchar(30) not null,
adresa nvarchar(150) not null,
id_zamestnance int foreign key (id_zamestnance) references osoby(id_osob) on delete cascade,
); 

create table problemy(
id_problemu int IDENTITY(1,1) primary key not null,
zaklad_problemu int foreign key (zaklad_problemu) references ucty(id_uct) on delete cascade,
datum_zalozeni datetime not null,
popis_problemu nvarchar(500),
vyresen varchar(3) NOT NULL CHECK (vyresen IN('Ano', 'Ne'))
);

create table transakce(
id_tran int IDENTITY(1,1) primary key not null,
odesilatel int foreign key (odesilatel) references ucty(id_uct),
prijemce int foreign key (prijemce) references ucty(id_uct),
castka_tran decimal not null,
datum_tran datetime not null,
);

create table kontokorenty(
id_kontok int IDENTITY(1,1) primary key not null,
vlastnik_kontok int foreign key (vlastnik_kontok) references ucty(id_uct),
stav_kontok varchar(6) NOT NULL CHECK (stav_kontok IN('zapnut', 'vypnut')), --ENUM parametr
castka_kontok decimal,
vycerpano_kontok decimal
);



insert into osoby (jmeno, prijmeni, dat_naroz, pohlavi,tel_cis, email, rodne_cis, cislo_op, adresa)values
('david', 'Cihak', '2003-01-01', 'male', 727940949, 'dwd@', 010203491, 064654351, 'Juhu Adresa'),
('Marek', 'Novak', '2002-02-02', 'male', 727940949, 'mama@', 010323494, 062354352, 'Juhu Adresa'),
('Adam', '�ustr', '2002-02-02', 'male', 727940949, 'asus@', 22223494, 222354352, 'Juhu Adresa');

insert into ucty (vlastnik, username, heslo, typ_uctu, balance, cislo_uctu)values
(1, 'david', 'david', 'zakaznik', 1000, '33333333331010'),
(2, 'marek', 'marek', 'banker', 2000, '2222222221010'),
(3, 'adam', 'adam', 'zakaznik', 100, '1111111111010');

use BankDB;
insert into kontokorenty(vlastnik_kontok,stav_kontok,castka_kontok, vycerpano_kontok)values
(1, 'vypnut', 1000, 0),
(3, 'zapnut', 1000, 500);

insert into transakce(odesilatel, prijemce, castka_tran, datum_tran)values
(1,2, 200, '2020-02-03 10:03:00'),
(1,2, 200, '2020-02-03 10:00:00'),
(1,2, 100, '2021-03-01 12:00:00'),
(2,1, 200, '2020-02-03 10:01:00');

use BankDB;
SELECT *
FROM osoby o
INNER JOIN ucty u ON o.id_osob = u.vlastnik
WHERE o.cislo_op = 064654351
AND u.heslo = 'david';


select username, heslo, typ_uctu from ucty where username = 'david' and heslo = 'david';

select id_osob, jmeno from osoby where id_osob = 2;

Update ucty
    set balance = balance +1
    where cislo_uctu = '2222222221010';

	use BankDB;
	select * from ucty;

	Select * from transakce where odesilatel = 1;

	update kontokorenty
	set castka_kontok = 1000
	where vlastnik_kontok = 1;

	use BankDB;
	select * from kontokorenty;

	insert into problemy (zaklad_problemu, datum_zalozeni, popis_problemu, vyresen)values
(1, GETUTCDATE(), 'blaBlaBla', 'Ne');

use BankDB;
select * from problemy;

use BankDB;
select * from osoby;
select * from ucty;

