﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BankApp.Ucty_metody;
using static BankApp.Osoby_metody;
using static BankApp.Pripojeni_db;
using System.Security.Cryptography.X509Certificates;

namespace BankApp
{
    public partial class Uzivatel_ui : Form
    {
        List<string> ucetUdaje = new List<string>();
        List<string> osobyUdaje = new List<string>();

        public Uzivatel_ui()
        {
            
            InitializeComponent();
            ucetUdaje.Clear();
            osobyUdaje.Clear();
            ucetUdaje = UcetVse();
            osobyUdaje = OsobyVse(ucetUdaje[1]);
            Ucet u1 = new Ucet(ucetUdaje[0], ucetUdaje[1], ucetUdaje[2], ucetUdaje[3], ucetUdaje[4], ucetUdaje[5], ucetUdaje[6]);
            Osoba o1 = new Osoba(osobyUdaje[0], osobyUdaje[1], osobyUdaje[2], osobyUdaje[3], osobyUdaje[4], osobyUdaje[5], osobyUdaje[6], osobyUdaje[7], osobyUdaje[8], osobyUdaje[9]);

            jmenoUziv.Text = o1.Jmeno +" "+ o1.Prijmeni;
            vyseZustatku.Text = u1.Balance;
            
        }

  

        private void platby_Click(object sender, EventArgs e)
        {
            this.Hide();
            Platby_ui p1 = new Platby_ui();
            p1.Show();
        }

        private void problemy_Click(object sender, EventArgs e)
        {
            this.Hide();
            NahlasProblem_ui np1 = new NahlasProblem_ui();
            np1.Show();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Prihlaseni_ui prih1 = new Prihlaseni_ui();
            prih1.Show();
        }

        private void kontokorentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Transakce_ui trans1 = new Transakce_ui();
            trans1.Show();
        }

        private void kontokorentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                Kontokorent_ui kk1 = new Kontokorent_ui();
                kk1.Show();
            } catch(Exception ex)
            {
                MessageBox.Show("Ještě nemáte od banky schváleno užívání kontokorentu.");
                this.Hide();
                Uzivatel_ui a1 = new Uzivatel_ui();
                a1.ShowDialog();
            }
        }

        private void nastaveníToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Nastaveni_ui nas1 = new Nastaveni_ui();
            nas1.Show();

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Prihlaseni_ui prih1 = new Prihlaseni_ui();
            prih1.Show();
        }
    }
}
