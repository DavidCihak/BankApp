﻿namespace BankApp
{
    partial class Uzivatel_ui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.zustatek = new System.Windows.Forms.Label();
            this.vyseZustatku = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.uzivMenu = new System.Windows.Forms.MenuStrip();
            this.platby = new System.Windows.Forms.ToolStripMenuItem();
            this.kontokorentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kontokorentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.problemy = new System.Windows.Forms.ToolStripMenuItem();
            this.nastaveníToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jmenoUziv = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.uzivMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 0;
            // 
            // zustatek
            // 
            this.zustatek.AutoSize = true;
            this.zustatek.Font = new System.Drawing.Font("Sitka Banner", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.zustatek.Location = new System.Drawing.Point(11, 11);
            this.zustatek.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.zustatek.Name = "zustatek";
            this.zustatek.Size = new System.Drawing.Size(107, 35);
            this.zustatek.TabIndex = 2;
            this.zustatek.Text = "Zůstatek:";
            this.zustatek.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // vyseZustatku
            // 
            this.vyseZustatku.AutoSize = true;
            this.vyseZustatku.Font = new System.Drawing.Font("Sitka Banner", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.vyseZustatku.Location = new System.Drawing.Point(122, 11);
            this.vyseZustatku.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.vyseZustatku.Name = "vyseZustatku";
            this.vyseZustatku.Size = new System.Drawing.Size(27, 35);
            this.vyseZustatku.TabIndex = 3;
            this.vyseZustatku.Text = "0";
            this.vyseZustatku.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.zustatek);
            this.panel1.Controls.Add(this.vyseZustatku);
            this.panel1.Location = new System.Drawing.Point(12, 65);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(337, 75);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // uzivMenu
            // 
            this.uzivMenu.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.uzivMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.platby,
            this.kontokorentToolStripMenuItem,
            this.kontokorentToolStripMenuItem1,
            this.problemy,
            this.nastaveníToolStripMenuItem});
            this.uzivMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.uzivMenu.Location = new System.Drawing.Point(0, 0);
            this.uzivMenu.Name = "uzivMenu";
            this.uzivMenu.Size = new System.Drawing.Size(716, 26);
            this.uzivMenu.TabIndex = 6;
            this.uzivMenu.Text = "menuStrip1";
            // 
            // platby
            // 
            this.platby.Name = "platby";
            this.platby.Size = new System.Drawing.Size(138, 22);
            this.platby.Text = "Odeslat peníze";
            this.platby.Click += new System.EventHandler(this.platby_Click);
            // 
            // kontokorentToolStripMenuItem
            // 
            this.kontokorentToolStripMenuItem.Name = "kontokorentToolStripMenuItem";
            this.kontokorentToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.kontokorentToolStripMenuItem.Text = "Historie transakcí";
            this.kontokorentToolStripMenuItem.Click += new System.EventHandler(this.kontokorentToolStripMenuItem_Click);
            // 
            // kontokorentToolStripMenuItem1
            // 
            this.kontokorentToolStripMenuItem1.Name = "kontokorentToolStripMenuItem1";
            this.kontokorentToolStripMenuItem1.Size = new System.Drawing.Size(120, 22);
            this.kontokorentToolStripMenuItem1.Text = "Kontokorent";
            this.kontokorentToolStripMenuItem1.Click += new System.EventHandler(this.kontokorentToolStripMenuItem1_Click);
            // 
            // problemy
            // 
            this.problemy.Name = "problemy";
            this.problemy.Size = new System.Drawing.Size(178, 22);
            this.problemy.Text = "Nahlášení problému";
            this.problemy.Click += new System.EventHandler(this.problemy_Click);
            // 
            // nastaveníToolStripMenuItem
            // 
            this.nastaveníToolStripMenuItem.Name = "nastaveníToolStripMenuItem";
            this.nastaveníToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.nastaveníToolStripMenuItem.Text = "Nastavení";
            this.nastaveníToolStripMenuItem.Click += new System.EventHandler(this.nastaveníToolStripMenuItem_Click);
            // 
            // jmenoUziv
            // 
            this.jmenoUziv.AutoSize = true;
            this.jmenoUziv.Font = new System.Drawing.Font("Sitka Small", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.jmenoUziv.Location = new System.Drawing.Point(489, 37);
            this.jmenoUziv.Name = "jmenoUziv";
            this.jmenoUziv.Size = new System.Drawing.Size(75, 28);
            this.jmenoUziv.TabIndex = 11;
            this.jmenoUziv.Text = "Jmeno";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BankApp.Properties.Resources.arrow_4957487_1280;
            this.pictureBox1.Location = new System.Drawing.Point(671, 374);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 39);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::BankApp.Properties.Resources.money_2831248_1280;
            this.pictureBox2.Location = new System.Drawing.Point(12, 167);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(209, 186);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // Uzivatel_ui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Orchid;
            this.ClientSize = new System.Drawing.Size(716, 414);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.jmenoUziv);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.uzivMenu);
            this.MainMenuStrip = this.uzivMenu;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Uzivatel_ui";
            this.Text = "Rozcestnik";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.uzivMenu.ResumeLayout(false);
            this.uzivMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label zustatek;
        private Label vyseZustatku;
        private GroupBox groupBox1;
        private Panel panel1;
        private MenuStrip uzivMenu;
        private ToolStripMenuItem platby;
        private ToolStripMenuItem kontokorentToolStripMenuItem;
        private ToolStripMenuItem kontokorentToolStripMenuItem1;
        private ToolStripMenuItem problemy;
        private ToolStripMenuItem nastaveníToolStripMenuItem;
        private Label jmenoUziv;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}