﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    internal class Kontokorent
    {
        // Definice vlastností pro jednotlivé atributy kontokorenty

        // Identifikátor kontokorenty
        private string idKontok;
        public string IdKontok
        {
            get { return idKontok; }
            set { idKontok = value; }
        }

        // Vlastník kontokorenty
        private string vlastnikKontok;
        public string VlastnikKontok
        {
            get { return vlastnikKontok; }
            set { vlastnikKontok = value; }
        }

        // Stav kontokorenty
        private string stavKontoko;
        public string StavKontoko
        {
            get { return stavKontoko; }
            set { stavKontoko = value; }
        }

        // Částka na kontokorente
        private string castkaKontok;
        public string CastkaKontok
        {
            get { return castkaKontok; }
            set { castkaKontok = value; }
        }

        // Vycerpano na kontokorente
        public string vycerpanoKontok;

        // Vlastnost pro vycerpano na kontokorente
        public string VycerpanoKontok
        {
            get { return vycerpanoKontok; }
            set { vycerpanoKontok = value; }
        }

        // Konstruktor pro vytvoření objektu Kontokorent s nastavením atributů
        public Kontokorent(string idKontok, string vlastnikKontok, string stavKontoko, string castkaKontok, string vycerpanoKontok)
        {
            // Nastavení hodnot atributů nového objektu na základě poskytnutých parametrů
            this.idKontok = idKontok;
            this.vlastnikKontok = vlastnikKontok;
            this.stavKontoko = stavKontoko;
            this.castkaKontok = castkaKontok;
            this.vycerpanoKontok = vycerpanoKontok;
        }
    }
}
