﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web; // Importuje se prostředí pro práci s webovými aplikacemi

namespace BankApp
{
    public class Ucet
    {
        // Privátní proměnné pro uchování informací o účtu
        private string idUct;
        private string vlastnik;
        private string username;
        private string heslo;
        private string typUctu;
        private string balance;
        private string cisloUctu;

        // Gettery a settery pro přístup k privátním proměnným
        public string IdUct
        {
            get { return idUct; }
            set { idUct = value; }
        }

        public string Vlastnik
        {
            get { return vlastnik; }
            set { vlastnik = value; }
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Heslo
        {
            get { return heslo; }
            set { heslo = value; }
        }

        public string TypUctu
        {
            get { return typUctu; }
            set { typUctu = value; }
        }

        public string Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        public string CisloUctu
        {
            get { return cisloUctu; }
            set { cisloUctu = value; }
        }

        // Konstruktor pro objekt Ucet, který inicializuje informace o účtu
        public Ucet(string idUct, string vlastnik, string username, string heslo, string typUctu, string balance, string cisloUctu)
        {
            // Inicializace hodnot předaných do konstruktoru do odpovídajících proměnných
            this.idUct = idUct;
            this.vlastnik = vlastnik;
            this.username = username;
            this.heslo = heslo;
            this.typUctu = typUctu;
            this.balance = balance;
            this.cisloUctu = cisloUctu;
        }
    }
}
