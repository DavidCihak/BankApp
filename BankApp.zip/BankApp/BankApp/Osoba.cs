﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    public class Osoba
    {
        // Privátní proměnné reprezentující atributy osoby
        private string idOsob;
        private string jmeno;
        private string prijmeni;
        private string datNaroz;
        private string pohlavi;
        private string telCis;
        private string email;
        private string rodneCis;
        private string cisloOp;
        private string adresa;

        // Vlastnosti pro přístup k atributům osoby

        public string IdOsob
        {
            get { return idOsob; }
            set { idOsob = value; }
        }

        public string Jmeno
        {
            get { return jmeno; }
            set { jmeno = value; }
        }

        public string Prijmeni
        {
            get { return prijmeni; }
            set { prijmeni = value; }
        }

        public string DatNaroz
        {
            get { return datNaroz; }
            set { datNaroz = value; }
        }

        public string Pohlavi
        {
            get { return pohlavi; }
            set { pohlavi = value; }
        }

        public string TelCis
        {
            get { return telCis; }
            set { telCis = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string RodneCis
        {
            get { return rodneCis; }
            set { rodneCis = value; }
        }

        public string CisloOp
        {
            get { return cisloOp; }
            set { cisloOp = value; }
        }

        public string Adresa
        {
            get { return adresa; }
            set { adresa = value; }
        }

        // Konstruktor pro vytvoření objektu Osoba s nastavením atributů

        public Osoba(string idOsob, string jmeno, string prijmeni, string datNaroz, string pohlavi, string telCis, string email, string rodneCis, string cisloOp, string adresa)
        {
            // Nastavení hodnot atributů nového objektu na základě poskytnutých parametrů
            this.idOsob = idOsob;
            this.jmeno = jmeno;
            this.prijmeni = prijmeni;
            this.datNaroz = datNaroz;
            this.pohlavi = pohlavi;
            this.telCis = telCis;
            this.email = email;
            this.rodneCis = rodneCis;
            this.cisloOp = cisloOp;
            this.adresa = adresa;
        }
    }
}
