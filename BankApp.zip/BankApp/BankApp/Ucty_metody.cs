﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using static BankApp.Pripojeni_db;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BankApp
{
    internal class Ucty_metody
    {
        
        public static bool CheckUsername(string usernameNew)//ověruje dostupnost uzivatelskeho jmena
        {
            bool existuje = false;
            try
            {
                SqlConnection cnn = ConnectDB();
                
                string usernameZDB = null;
                string prikazB = "select username from ucty where username ='" + usernameNew + "';";
                SqlCommand commandB = new SqlCommand(prikazB, cnn);


                using (SqlDataReader reader = commandB.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        usernameZDB = reader["username"].ToString();
                    }
                }
                if (usernameNew == usernameZDB)
                {
                    existuje = true;
                }
                else
                {
                    existuje = false;
                }
                return existuje;
            }catch(Exception ex)
            {
                
                    MessageBox.Show("Chyba CheckUsername");
                return existuje;
            }
        }
        
       

        public static string RodneCisloNaDatumNarozeni(string rodneCislo)//metoda která z rodneho cisla udela datum narozeni.
        {
            try
            {
                int day = int.Parse(rodneCislo.Substring(4, 2));
                int month = int.Parse(rodneCislo.Substring(2, 2));
                int yearPrefix = int.Parse(rodneCislo.Substring(0, 2));

                int year;
                if (yearPrefix >= 54)
                {
                    year = 1900 + yearPrefix;
                }
                else
                {
                    year = 2000 + yearPrefix;
                }

                // Vytvoření formátu RRRR-MM-DD
                string formattedDate = $"{year:D4}-{month:D2}-{day:D2}";
                return formattedDate;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nejspise spatne rodne cislo;Chyba RodneCisloNaDatumNarozeni");
               
                return "1000-01-01";
            }
        }

        
        public static string GetVlastnikThruOp(string cisloOp)//vrati id osoby která je vlastníkem účtu který má konkrétní cislo op
        {
            try
            {
                SqlConnection cnn = ConnectDB();
                string vlastnik = null;
                string prikazB = "select id_osob from osoby where cislo_op =" + cisloOp + ";";
                SqlCommand commandB = new SqlCommand(prikazB, cnn);


                using (SqlDataReader reader = commandB.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        vlastnik = reader["id_osob"].ToString();
                    }
                }
                return vlastnik;
            } catch(Exception ex)
            {
                MessageBox.Show("Chyba GetVlastnikThruO");
                return null;
            }
        }

        public static void NovyUcet(string username, string heslo, string cisloOp)//vytváří nový záznam v tabulce ucty. Vytvari se společně při registraci osoby.
        {
            try { 
            SqlConnection cnn = ConnectDB();
            Random rng = new Random();
            int number = rng.Next(100000000, 999999999);
            string cislo_uctu = number.ToString()+"1010";
            MessageBox.Show("Toto bude číslo vašeho účtu¨: " + cislo_uctu + " zapište si ho!");
            string vlastnik = GetVlastnikThruOp(cisloOp);

            string prikazUcet = "insert into ucty (vlastnik, username, heslo, typ_uctu, balance, cislo_uctu)values\r\n("+vlastnik+", '"+username+"', '"+heslo+"', 'zakaznik', 1000, '"+cislo_uctu+"');";
            SqlCommand command = new SqlCommand(prikazUcet, cnn);
           /* command.Parameters.Add("@vlastnik", SqlDbType.NVarChar);
            command.Parameters["@vlastnik"].Value = vlastnik;
            command.Parameters.Add("@username", SqlDbType.NVarChar);
            command.Parameters["@username"].Value = username;
            command.Parameters.Add("@heslo", SqlDbType.NVarChar);
            command.Parameters["@heslo"].Value = heslo;
            command.Parameters.Add("@cislo_uctu", SqlDbType.NVarChar);
            command.Parameters["@cislo_uctu"].Value = cislo_uctu;*/

            command.ExecuteNonQuery();

            cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba NovyUcet");
                
            }


        }
        
        
            public static string Get_Id_presCisloUctu(string cisloUctu)//vrati id uctu pres cislo uctu
            {
            try
            {
                string id = null;
                SqlConnection cnn = ConnectDB();
                string prikaz = "select id_uct from ucty where cislo_uctu = '" + cisloUctu + "' ;";
                SqlCommand command = new SqlCommand(prikaz, cnn);


                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        id = reader["id_uct"].ToString();
                    }
                }
                return id;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba Get_Id_presCisloUctu");
                return null;

            }
        }
        public static string Get_Jmeno_prijmeni_presCisloUctu(string cisloUctu)//vrati jmeno a prijmeni pres cislo uctu zobrazuje se pri posilani penez
        {
            try { 
            string jmeno = null;
            string prijmeni = null;
            string vlastnik = null;
            SqlConnection cnn = ConnectDB();
            string prikaz = "select vlastnik from ucty where cislo_uctu = '" + cisloUctu + "' ;";
            SqlCommand command = new SqlCommand(prikaz, cnn);


            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    vlastnik = reader["vlastnik"].ToString();
                }
            }



            string prikazB = "select jmeno, prijmeni from Osoby where id_osob = " + vlastnik + ";";
            SqlCommand commandB = new SqlCommand(prikazB, cnn);


            using (SqlDataReader reader = commandB.ExecuteReader())
            {
                while (reader.Read())
                {
                    jmeno = reader["jmeno"].ToString();
                    prijmeni = reader["prijmeni"].ToString();
                }
            }
            return jmeno + " " + prijmeni;
        }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba Get_Jmeno_prijmeni_presCisloUctu");
                return null;

            }
}
       
        public static void OdectiPenize(decimal castka)//odecita posilane penize z uctu odesilatele
        {
            try { 
            //odečtení peněz
            SqlConnection cnn = ConnectDB();
            string id_uct = Get_id_uctu(get_login());
            string balance = Get_balance(id_uct);
            decimal newBalance = decimal.Parse(balance);
            newBalance = newBalance - castka;
            string prikaz = "update ucty set balance = " + newBalance.ToString() + " where id_uct = " + id_uct + ";";
            SqlCommand command = new SqlCommand(prikaz, cnn);
            command.ExecuteNonQuery();
            cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba OdectiPenize");
            }

        }
        
        public static void PoslatPenize(decimal castka, string komu)//pricita penize k uctu prijemce
        {
            try { 
            SqlConnection cnn = ConnectDB();


            //připsání peněz

            string prikaz2 = "update ucty set balance =  balance + " + castka + " where cislo_uctu = '" + komu + "';";
            SqlCommand command2 = new SqlCommand(prikaz2, cnn);
            command2.ExecuteNonQuery();
            cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba OdectiPenize");
            }

        }
        public static List<string> UcetVse()//vrati vsechny potrebne udaje o uctu aktualne prihlasenym.
        {

            List<string> udaje = new List<string>();
            try { 
            SqlConnection cnn = ConnectDB();
            string prikaz_udaje = "Select * from ucty where username = '" + get_login() + "';";
            SqlCommand command2 = new SqlCommand(prikaz_udaje, cnn);

            using (SqlDataReader reader = command2.ExecuteReader())
            {
                while (reader.Read())
                {
                    udaje.Add(reader["id_uct"].ToString());
                    udaje.Add(reader["vlastnik"].ToString());
                    udaje.Add(reader["username"].ToString());
                    udaje.Add(reader["heslo"].ToString());
                    udaje.Add(reader["typ_uctu"].ToString());
                    udaje.Add(reader["balance"].ToString());
                    udaje.Add(reader["cislo_uctu"].ToString());
                }
            }
            cnn.Close();
            return udaje;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba UcetVse");
            return udaje;
            }
        }
        public static string Get_balance(string id_uctu)//vrati hodnotu penez na ucte akutalne prihlasenem
        {
            try { 
            string balance = null;
            SqlConnection cnn = ConnectDB();
            Dictionary<string, string> login_heslo_db = new Dictionary<string, string>();
            string prikaz = "select balance from ucty where id_uct = @log";
            SqlCommand command = new SqlCommand(prikaz, cnn);
            command.Parameters.Add("@log", SqlDbType.NVarChar);
            command.Parameters["@log"].Value = id_uctu;

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    balance = reader["balance"].ToString();
                }
            }
            return balance;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba Get_balance");
                return null;
            }
        }

        public static void UpdateUsernameHeslo(string newHeslo, string newUsername, string cislo_uctu)//spusti se pro změnu hesla nebo username z adminskeho uctu
        {
            try { 

            SqlConnection cnn = ConnectDB();

            string prikaz = "update ucty set heslo = @heslo, username = @log where cislo_uctu= @cislo_uctu;";
            
            SqlCommand command = new SqlCommand(prikaz, cnn);
            command.Parameters.Add("@log", SqlDbType.NVarChar);
            command.Parameters["@log"].Value = newUsername;
            command.Parameters.Add("@heslo", SqlDbType.NVarChar);
            command.Parameters["@heslo"].Value = newHeslo;
            command.Parameters.Add("@cislo_uctu", SqlDbType.NVarChar);
            command.Parameters["@cislo_uctu"].Value = cislo_uctu;
            command.ExecuteNonQuery();
            cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba UpdateUsernameHeslo");
                
            }
        }
        public static void UpdateHeslo(string newHeslo)//upravi pouze heslo
        {
            try { 
            
            SqlConnection cnn = ConnectDB();
     
            string prikaz = "update ucty set heslo = '"+ newHeslo  +"' where id_uct = " + Get_id_uctu(get_login()) + ";";
            SqlCommand command = new SqlCommand(prikaz, cnn);
            command.ExecuteNonQuery();          
            cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba UpdateHeslo");

            }
        }
        public static void UpdateUsername(string newUsername)//upravi pouze username
        {
            try { 
            SqlConnection cnn = ConnectDB();

            string prikaz = "update ucty set username = '" + newUsername + "' where id_uct = " + Get_id_uctu(get_login()) + ";";
            SqlCommand command = new SqlCommand(prikaz, cnn);
            command.ExecuteNonQuery();
            cnn.Close();
        }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba UpdateUsername");
                
            }
}
        public static string Get_id_uctu(string username)//vrati id uctu pres atribut username
        {
            try
            {
                string id_uct = null;
                SqlConnection cnn = ConnectDB();
                Dictionary<string, string> login_heslo_db = new Dictionary<string, string>();
                string prikaz = "select id_uct from ucty where username = @log";
                SqlCommand command = new SqlCommand(prikaz, cnn);
                command.Parameters.Add("@log", SqlDbType.NVarChar);
                command.Parameters["@log"].Value = username;

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        id_uct = reader["id_uct"].ToString();
                    }
                }
                return id_uct;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chyba UpdateUsernameHeslo");
                return null;

            }

        }  
    }
}
