﻿using System.Data.SqlClient;
using System.Data;
using static BankApp.Pripojeni_db;
using static BankApp.Uzivatel_ui;
using static BankApp.Ucty_metody;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace BankApp
{
    internal class Osoby_metody
    {
        public static List<string> OsobaPresOpHeslo(string cislo_op, string heslo)//Vrátí údaje o osobě na základě cisla op a hesla k účtu.
        {
            List<string> udaje = new List<string>();
            try
            {

                SqlConnection cnn = ConnectDB();
                string prikaz = "use BankDB;\r\nSELECT *\r\nFROM osoby o\r\nINNER JOIN ucty u ON o.id_osob = u.vlastnik\r\nWHERE o.cislo_op = " + cislo_op + "\r\nAND u.heslo = '" + heslo + "';";
                SqlCommand command2 = new SqlCommand(prikaz, cnn);

                using (SqlDataReader reader = command2.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        udaje.Add(reader["jmeno"].ToString());
                        udaje.Add(reader["prijmeni"].ToString());
                        udaje.Add(reader["email"].ToString());
                        udaje.Add(reader["tel_cis"].ToString());
                        udaje.Add(reader["rodne_cis"].ToString());
                        udaje.Add(reader["cislo_op"].ToString());
                        udaje.Add(reader["username"].ToString());
                        udaje.Add(reader["heslo"].ToString());
                        udaje.Add(reader["balance"].ToString());
                        udaje.Add(reader["cislo_uctu"].ToString());
                        udaje.Add(reader["id_uct"].ToString());
                    }
                }
                cnn.Close();
                return udaje;
            }catch(Exception ex)
            {

                    Console.WriteLine("Chyba v OsobaPresOPHeslo");
                return udaje;
            }
        }

        public static bool CheckOP(string cislo_op, string rodne_cis)//Zkontroluje existenci osoby v databázi pomocí čísla OP a rodného čísla.
        {
            bool existuje = false;
            try
            {


                SqlConnection cnn = ConnectDB();
                
                string opZDB = null;
                string rodne_cisZDB = null;
                string prikazA = "select cislo_op from osoby where cislo_op =" + cislo_op + ";";
                string prikazB = "select rodne_cis from osoby where rodne_cis =" + rodne_cis + ";";
                SqlCommand commandA = new SqlCommand(prikazA, cnn);
                SqlCommand commandB = new SqlCommand(prikazB, cnn);


                using (SqlDataReader reader = commandA.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        opZDB = reader["cislo_op"].ToString();
                    }
                }
                using (SqlDataReader reader = commandB.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        rodne_cisZDB = reader["rodne_cis"].ToString();
                    }
                }
                if (rodne_cis == rodne_cisZDB || cislo_op == opZDB)
                {
                    existuje = true;
                }
                else
                {
                    existuje = false;
                }
                return existuje;
            }catch (Exception ex)
            {
                
                     MessageBox.Show("Chyba CheckOP");
                return existuje;
            }

        }
        //Přidá novou osobu do databáze s příslušnými informacemi. (Zaregistruje).
        public static void NovaOsoba(string jmeno, string prijmeni, string dat_narozeni, string pohlavi, string tel_cis, string email, string rodne_cis, string cislo_op, string adresa)
        {
            try
            {
                SqlConnection cnn = ConnectDB();

                string prikazOsoba = "insert into osoby (jmeno, prijmeni, dat_naroz, pohlavi, tel_cis, email, rodne_cis, cislo_op, adresa)values\r\n('" + jmeno + "', '" + prijmeni + "', '" + dat_narozeni + "', 'male', " + tel_cis + ", '" + email + "', " + rodne_cis + ", " + cislo_op + ", '" + adresa + "');";
                SqlCommand command = new SqlCommand(prikazOsoba, cnn);
                /*command.Parameters.Add("@jmeno", SqlDbType.NVarChar);
                command.Parameters["@jmeno"].Value = jmeno;
                command.Parameters.Add("@prijmeni", SqlDbType.NVarChar);
                command.Parameters["@prijmeni"].Value = prijmeni;
                command.Parameters.Add("@dat_naroz", SqlDbType.NVarChar);
                command.Parameters["@dat_naroz"].Value = dat_narozeni;
                command.Parameters.Add("@pohlavi", SqlDbType.VarChar);
                command.Parameters["@pohlavi"].Value = pohlavi;
                command.Parameters.Add("@tel_cis", SqlDbType.Int);
                command.Parameters["@tel_cis"].Value = tel_cis;
                command.Parameters.Add("@email", SqlDbType.NVarChar);
                command.Parameters["@email"].Value = email;
                command.Parameters.Add("@rodne_cis", SqlDbType.Int);
                command.Parameters["@rodne_cis"].Value = rodne_cis;
                command.Parameters.Add("@cislo_op", SqlDbType.Int);
                command.Parameters["@cislo_op"].Value = cislo_op;
                command.Parameters.Add("@adresa", SqlDbType.NVarChar);
                command.Parameters["@adresa"].Value = adresa;*/
                command.ExecuteNonQuery();

                cnn.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Chyba NovaOsoba");
            }

        }
        public static List<string> OsobyVse(string vlastnik)//Získá informace o osobě na základě identifikátoru vlastníka.
        {
            List<string> udajeOsob = new List<string>();
            try
            {
               
                SqlConnection cnn = ConnectDB();
                udajeOsob.Clear();
                string prikaz_udaje = "Select * from osoby where id_osob = " + vlastnik + ";";
                SqlCommand command2 = new SqlCommand(prikaz_udaje, cnn);

                using (SqlDataReader reader = command2.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        udajeOsob.Add(reader["id_osob"].ToString());
                        udajeOsob.Add(reader["jmeno"].ToString());
                        udajeOsob.Add(reader["prijmeni"].ToString());
                        udajeOsob.Add(reader["dat_naroz"].ToString());
                        udajeOsob.Add(reader["pohlavi"].ToString());
                        udajeOsob.Add(reader["tel_cis"].ToString());
                        udajeOsob.Add(reader["email"].ToString());
                        udajeOsob.Add(reader["rodne_cis"].ToString());
                        udajeOsob.Add(reader["cislo_op"].ToString());
                        udajeOsob.Add(reader["adresa"].ToString());
                    }
                }
                cnn.Close();
                return udajeOsob;
            }
            catch (Exception e)
            {

                MessageBox.Show("Chyba OsobyVse");
                return udajeOsob;
            }
        }
        public static string GetJmenoPrijmeniPresId(string id_osob)//Vrátí jméno a příjmení osoby na základě identifikátoru.
        {
            try { 
            SqlConnection cnn = ConnectDB();
            string jmeno = null;
            string prijmeni = null;
            string prikazB = "select jmeno, prijmeni from Osoby where id_osob =" + id_osob + ";";
            SqlCommand commandB = new SqlCommand(prikazB, cnn);


            using (SqlDataReader reader = commandB.ExecuteReader())
            {
                while (reader.Read())
                {
                    jmeno = reader["jmeno"].ToString();
                    prijmeni = reader["prijmeni"].ToString();
                }
            }
            return jmeno + " " + prijmeni;
            }
            catch (Exception e)
            {

                MessageBox.Show("Chyba GetJmenoPrijmeniPresId");
                return null;
            }
        }
        public static string Get_jmeno_prijmeni(string username)//Získá jméno a příjmení osoby na základě uživatelského jména.
        {
            try { 
            string jmenoprijmeni = null;
            SqlConnection cnn = ConnectDB();
            Dictionary<string, string> login_heslo_db = new Dictionary<string, string>();
            string prikaz = "select jmeno, prijmeni from osoby where id_osob = @log";
            SqlCommand command = new SqlCommand(prikaz, cnn);
            command.Parameters.Add("@log", SqlDbType.NVarChar);
            command.Parameters["@log"].Value = Get_id_uctu(username);

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    jmenoprijmeni = reader["jmeno"].ToString();
                    jmenoprijmeni = jmenoprijmeni + " " + reader["prijmeni"].ToString();
                }
            }
            return jmenoprijmeni;
            }
            catch (Exception e)
            {

                MessageBox.Show("Chyba Get_jmeno_prijmeni");
                return null;
            }
        }
        public static void UpdateOsoba(string cislo_op, List<string> noveUdaje)//UpdateOsoba: Aktualizuje informace o osobě v databázi na základě čísla OP.
        {
            try { 
            SqlConnection cnn = ConnectDB();
            string prikaz = "update osoby set  jmeno = @jmeno, prijmeni = @prijmeni, email = @email, tel_cis = @telefon, rodne_cis = @rodne_cis, cislo_op = @cislo_opnew where cislo_op = @cislo_op;";
            SqlCommand command = new SqlCommand(prikaz, cnn);
            command.Parameters.Add("@jmeno", SqlDbType.NVarChar);
            command.Parameters["@jmeno"].Value = noveUdaje[0];
            command.Parameters.Add("@prijmeni", SqlDbType.NVarChar);
            command.Parameters["@prijmeni"].Value = noveUdaje[1];
            command.Parameters.Add("@email", SqlDbType.NVarChar);
            command.Parameters["@email"].Value = noveUdaje[3];
            command.Parameters.Add("@telefon", SqlDbType.Int);
            command.Parameters["@telefon"].Value = noveUdaje[2];
            command.Parameters.Add("@rodne_cis", SqlDbType.Int);
            command.Parameters["@rodne_cis"].Value = noveUdaje[5];
            command.Parameters.Add("@cislo_opnew", SqlDbType.Int);
            command.Parameters["@cislo_opnew"].Value = noveUdaje[4];
            command.Parameters.Add("@cislo_op", SqlDbType.Int);
            command.Parameters["@cislo_op"].Value = cislo_op;
            command.ExecuteNonQuery();
            cnn.Close();
        }
            catch (Exception e)
            {

                MessageBox.Show("Chyba Update_osoba");
                
            }

}
    }
}
