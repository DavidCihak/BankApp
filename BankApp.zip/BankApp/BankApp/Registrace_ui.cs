﻿using static BankApp.Ucty_metody;
using static BankApp.Osoby_metody;
using System.Text.RegularExpressions;


namespace BankApp
{
    public partial class Registrace_ui : Form
    {
        public Registrace_ui()
        {
            InitializeComponent();
        }

        private void Registrace_ui_Load(object sender, EventArgs e)
        {

        }

     

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string jmeno = textBox1.Text;
            string prijmeni = textBox2.Text;
            

            string pohlavi = comboBox1.Text;
            if (pohlavi == "Muž")
            {
                pohlavi = "male";
            }
            else if (pohlavi == "Žena")
            {
                pohlavi = "female";
            }
            string tel_cis = textBox5.Text;
            string email = textBox6.Text;
            string rodne_cis = textBox8.Text;
            string cislo_op = textBox7.Text;
            string ad1 = textBox9.Text;
            string ad2 = textBox11.Text;
            string ad3 = textBox10.Text;
            string ad4 = textBox12.Text;
            string adresa = ad1 + " " + ad2 + ", " + ad3 + " " + ad4;
            string username = textBox4.Text;
            string heslo = textBox3.Text;
            



            
            string patternOPaTel = @"^\d{9}$";
            string patternAdresa = @"^\d+$";
            string patternRodCis = @"^\d{6}\d{4}$";
            string patternEmail = @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$";


            if (textBox1.TextLength == 0 || textBox2.TextLength == 0 || textBox3.TextLength == 0 || comboBox1.Text.Length == 0 || textBox9.TextLength == 0 || textBox10.TextLength == 0 || textBox11.TextLength == 0 || textBox12.TextLength == 0)
            {
                MessageBox.Show("Nemáte vyplněny všechny údaje!");
            }
            else if (CheckUsername(username))
            {
                MessageBox.Show("Toto uživatelské jméno již boužel existuje.");

            }
            else if (pohlavi == "Nemoc")
            {
                MessageBox.Show("Bohužel nemocnýcm neposkytujeme účty.");
            }
            else if (!Regex.IsMatch(tel_cis, patternOPaTel))
            {
                MessageBox.Show("Telefonní číslo musí obsahovat 9 číslic a žádné jiné znaky.");
            }
            else if (!Regex.IsMatch(cislo_op, patternOPaTel))
            {
                MessageBox.Show("Cislo občanky musí být dlouhé 9 znaků.");
            }
            else if (!Regex.IsMatch(rodne_cis, patternRodCis))
            {
                MessageBox.Show("Rodné číslo musí obsahovat 10 číslic a žádné jiné znaky.");
            }
            else if (!Regex.IsMatch(email, patternEmail))
            {
                MessageBox.Show("Email nené ve vhodném formátu.");
            }
            else if (!Regex.IsMatch(textBox11.Text, patternAdresa)||!Regex.IsMatch(textBox12.Text, patternAdresa))
            {
                MessageBox.Show("Zkontrolujte ČP a PSČ.");
            }
            else if (CheckOP(cislo_op, rodne_cis))
            {
                MessageBox.Show("Už u nás je účet evidovaný s tímto číslem OP nebo rodným číslem.");
            }
            else
            {
                string dat_narozeni = RodneCisloNaDatumNarozeni(rodne_cis);
                NovaOsoba(jmeno, prijmeni, dat_narozeni, pohlavi, tel_cis, email, rodne_cis, cislo_op, adresa);
                NovyUcet(username, heslo, cislo_op);
                MessageBox.Show("Váš účet byl vytvořen.");
            }
            this.Hide();
            Prihlaseni_ui prih1 = new Prihlaseni_ui();
            prih1.Show();
        } 

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Prihlaseni_ui prih1 = new Prihlaseni_ui();
            prih1.Show();

        }

     
    }
}
