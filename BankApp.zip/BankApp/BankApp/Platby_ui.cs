﻿using static BankApp.Ucty_metody;
using static BankApp.Pripojeni_db;
using static BankApp.Kontokorent_metody;
using static BankApp.Transakce_metody;




namespace BankApp
{
    public partial class Platby_ui : Form
    {
        public Platby_ui()
        {
            InitializeComponent();
            panel1.Hide();

            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Uzivatel_ui u1 = new Uzivatel_ui();
            u1.Show();
        }
        List<string> kontokotentUdaje = new List<string>();

        private void odeslatPlatbuButton_Click(object sender, EventArgs e)
        {
            kontokotentUdaje.Clear();
            kontokotentUdaje = Get_kontokortentALL();
            Kontokorent k1 = new Kontokorent(kontokotentUdaje[0], kontokotentUdaje[1], kontokotentUdaje[2], kontokotentUdaje[3], kontokotentUdaje[4]);
            if (numericUpDown1.Value < 1)
            {
                MessageBox.Show("Nelze odeslat méně než 1Kč.");

            }
            else if (comboBox1.Text.Length < 4 || textBox2.TextLength < 9)
            {
                MessageBox.Show("Zadejte prosím celé číslo účtu.");
            }
            else
            {

                    decimal castka = decimal.Parse(numericUpDown1.Value.ToString());
                    string komu = textBox2.Text + comboBox1.Text;
                    decimal balance = decimal.Parse(Get_balance(Get_id_uctu(get_login())));
                    decimal vycerpanoKontokD = decimal.Parse(k1.vycerpanoKontok);
                    decimal castkaKontokD = decimal.Parse(k1.CastkaKontok);

                if (balance < castka)
                {
                    DialogResult dialog2 = MessageBox.Show("Na vašem účtě nemáte dostatek prostředků.\n Přejete si použít peníze z kontokorenntu?", "Potvrzení", MessageBoxButtons.YesNo);
                    if (dialog2 == DialogResult.Yes)
                    {
                        if (castkaKontokD - vycerpanoKontokD + balance < castka || k1.StavKontoko == "vypnut")
                        {
                          
                            MessageBox.Show("Kontokorent je buď vypnutý, nebo na něm není dostatek peněz.");
                        }
                        else
                        {

                            decimal newValue = castkaKontokD - vycerpanoKontokD + balance - castka;
                            Update_kontokorentValue(newValue.ToString(), "vycerpano_kontok");
                            PoslatPenize(castka, komu);
                            OdectiPenize(balance);
                            NovaTransakce(Get_id_uctu(get_login()), komu, castka);
                            MessageBox.Show("Platba byla úspěšně odeslána.");
                        }
                    }
                }
                else
                {
                    DialogResult dialog1 = MessageBox.Show("Opravdu si přejete poslat peníze " + label5.Text, "Potvrzení", MessageBoxButtons.YesNo);
                    if (dialog1 == DialogResult.Yes)
                    {
                        PoslatPenize(castka, komu);
                        OdectiPenize(castka);
                        NovaTransakce(Get_id_uctu(get_login()), Get_Id_presCisloUctu(komu), castka);
                        MessageBox.Show("Platba byla úspěšně odeslána.");
                    }
                    else if (dialog1 == DialogResult.No)
                    {

                    }


                }
                
                
            }

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Uzivatel_ui u1 = new Uzivatel_ui();
            u1.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length < 9)
            {
                MessageBox.Show("Cislo účtu musí mít délku devíti čísel.");
            }
            else
            {
                try
                {
                    panel1.Show();
                    string cislouctu = textBox2.Text + comboBox1.Text;
                    label5.Text = Get_Jmeno_prijmeni_presCisloUctu(cislouctu);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Tento účet není v naší Databázi, zkuste zkontrolovat číslo účtu.");
                }
            }

        }

      
    }
}
