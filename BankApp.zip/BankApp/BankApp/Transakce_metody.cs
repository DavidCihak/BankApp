﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

using static BankApp.Pripojeni_db; // Importuje se Pripojeni_db pro přístup k metodám pro připojení k databázi
using static BankApp.Ucty_metody; // Importuje se Ucty_metody pro přístup k metodám týkajícím se účtů

namespace BankApp
{
    internal class Transakce_metody
    {

        // Metoda pro vytvoření nové transakce
        public static void NovaTransakce(string odesilatel, string prijemce, decimal castka_tran)
        {
            try { 
            SqlConnection cnn = ConnectDB(); // Připojení k databázi

            // Vytvoření SQL příkazu pro vložení nové transakce do databáze
            string prikazUcet = "insert into transakce(odesilatel, prijemce, castka_tran, datum_tran)values\r\n(" + odesilatel + "," + prijemce + ", " + castka_tran.ToString() + ", GETDATE());";
            SqlCommand command = new SqlCommand(prikazUcet, cnn); // Příprava SQL příkazu pro databázi
            command.ExecuteNonQuery(); // Provedení SQL příkazu
            cnn.Close(); // Uzavření spojení s databází
        }catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        // List pro ukládání informací o transakcích
        public static List<string> transakce = new List<string>();

        // Metoda pro získání seznamu transakcí za měsíc
        public static List<string> TransakceMesic()
        {
            try
            {
                transakce.Clear(); // Vyčištění seznamu transakcí
                SqlConnection cnn = ConnectDB(); // Připojení k databázi

                // SQL příkaz pro získání transakcí za měsíc
                string prikaz_udaje = "Select * from transakce where odesilatel = " + Get_id_uctu(get_login()) + ";";
                SqlCommand command2 = new SqlCommand(prikaz_udaje, cnn); // Příprava SQL příkazu pro databázi

                // Získání dat transakcí z databáze
                using (SqlDataReader reader = command2.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Přidání informací o transakci do seznamu
                        transakce.Add(reader["id_tran"].ToString());
                        transakce.Add(reader["odesilatel"].ToString());
                        transakce.Add(reader["prijemce"].ToString());
                        transakce.Add(reader["castka_tran"].ToString());
                        transakce.Add(reader["datum_tran"].ToString());
                    }
                }
                cnn.Close(); // Uzavření spojení s databází
                return transakce; // Vrácení seznamu transakcí
            }
            catch (Exception ex)
            {
                Console.WriteLine("Oprav metodu TransakceMesic");
                transakce.Clear();
                return transakce;
            }
        }
    
       
    }
}
