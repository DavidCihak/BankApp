﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BankApp.Pripojeni_db;
using static BankApp.Ucty_metody;
namespace BankApp
{
    internal class Problem_metody
    {
        public static void InsertProblem(string popisProblemu)//Přidá nový záznam do databáze s problémem a s klíčem zadavatele.
        {
            try
            {
                SqlConnection cnn = ConnectDB();
                string prikaz = "insert into problemy (zaklad_problemu, datum_zalozeni, popis_problemu, vyresen)values\r\n(" + Get_id_uctu(get_login()) + ", GETUTCDATE(), '" + popisProblemu + "', 'Ne');;";
                SqlCommand command = new SqlCommand(prikaz, cnn);
                command.ExecuteNonQuery();
                cnn.Close();
            }catch(Exception ex)
            {
                Console.WriteLine("Chyba InsertProblem");
            }
        }

    }
}
