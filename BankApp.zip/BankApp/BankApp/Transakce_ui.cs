﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BankApp.Transakce_metody;
using static BankApp.Pripojeni_db;
using static BankApp.Osoby_metody;
using static BankApp.Ucty_metody;


namespace BankApp
{
    public partial class Transakce_ui : Form
    {
        public Transakce_ui()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Uzivatel_ui a1 = new Uzivatel_ui();
            a1.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Uzivatel_ui u1 = new Uzivatel_ui();
            u1.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           
            
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            //výpis všech transakcí podle roku
            List<string> transakce = TransakceMesic();
            string[] datumCas = null;
            for (int i = 4; i < transakce.Count(); i = i + 5)
            {
               datumCas = Split_date_others(transakce[i]);
                string prijemce = GetJmenoPrijmeniPresId(transakce[i-2]);
                int pocetDat = datumCas.Length;
                for (int y = 2; y < pocetDat; y = y + 4)
                {
                    if (datumCas[y] == numericUpDown1.Value.ToString())
                    {
                        listBox1.Items.Add(transakce[i-1] + "Kč -> " + prijemce + " " + datumCas[0] + "." + datumCas[1] + ". " + datumCas[2] + " " + datumCas[3]);
                    }

                }
            }
            
            //3-rok 1-mesic 2-den 3-hodina-minuta-sec
            
            

        }

        private void Transakce_ui_Load(object sender, EventArgs e)
        {

        }
    }
}
