﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BankApp.Ucty_metody;
using static BankApp.Osoby_metody;

namespace BankApp
{
    public partial class Nastaveni_ui : Form
    {
        bool zmenaHes = false;
        bool zmenaUser = false;
        List<string> ucetUdaje = new List<string>();
        public Nastaveni_ui()
        {
            
            InitializeComponent();
            List<string> ucetUdaje = UcetVse();
            Ucet ucet = new Ucet(ucetUdaje[0], ucetUdaje[1], ucetUdaje[2], ucetUdaje[3], ucetUdaje[4], ucetUdaje[5], ucetUdaje[6]);
            List<string> osobyUdaje = OsobyVse(ucetUdaje[1]);
            Osoba osoba = new Osoba(osobyUdaje[0], osobyUdaje[1], osobyUdaje[2], osobyUdaje[3], osobyUdaje[4], osobyUdaje[5], osobyUdaje[6], osobyUdaje[7], osobyUdaje[8], osobyUdaje[9]);
            jmeno.Text = osoba.Jmeno;
            prijmeni.Text = osoba.Prijmeni;
            email.Text = osoba.Email;
            telefon.Text = osoba.TelCis;
            pohlavi.Text = osoba.Pohlavi;
            rodneCis.Text = osoba.RodneCis;
            IDCislo.Text = osoba.CisloOp;
            textBox4.Text = ucet.Username;
            textBox3.Text = ucet.Heslo;
            label12.Text = osoba.DatNaroz;
            label14.Text = osoba.Adresa;
            ucetUdaje.Clear();
            osobyUdaje.Clear();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            NahlasProblem_ui np1 = new NahlasProblem_ui();
            np1.Show();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Uzivatel_ui u1 = new Uzivatel_ui();
            u1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (zmenaHes == true)
            {
                UpdateHeslo(textBox3.Text);
                MessageBox.Show("Heslo bylo změněno znova se přihlašte");
            }
            else
            {
                MessageBox.Show("Zadne udaje nebyly změněny");
            }

            if (zmenaUser == true)
            {
                 UpdateUsername(textBox4.Text);
                 MessageBox.Show("Username bylo změněno znova se přihlašte");
            }
            else
            {
                MessageBox.Show("Zadne udaje nebyly změněny");
            }
            if(zmenaHes == true|| zmenaUser == true)
            {
                this.Hide();
                Prihlaseni_ui u1 = new Prihlaseni_ui();
                u1.Show();
            }


            ucetUdaje.Clear();

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            zmenaUser = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            zmenaHes = true;    
        }
    }
}
