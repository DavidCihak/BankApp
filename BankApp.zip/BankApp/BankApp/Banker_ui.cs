﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BankApp.Ucty_metody;
using static BankApp.Pripojeni_db;
using static BankApp.Osoby_metody;


namespace BankApp
{
    public partial class Banker_ui : Form
    {
        public Banker_ui()
        {
            InitializeComponent();
            label1.Text = Get_jmeno_prijmeni(get_login());
        }




        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Prihlaseni_ui u1 = new Prihlaseni_ui();
            u1.Show();
        }

        private void spravaUctuMenu_Click(object sender, EventArgs e)
        {

            this.Hide();
            SpravaUctu_ui np1 = new SpravaUctu_ui();
            np1.Show();

        }

        private void nastaveniToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            Nastaveni_ui np1 = new Nastaveni_ui();
            np1.Show();


        }
    }
}
