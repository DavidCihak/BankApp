using System.Data.SqlClient;
using static BankApp.Pripojeni_db;
namespace BankApp
{
    public partial class Prihlaseni_ui : Form
    {
        public Prihlaseni_ui()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
            private void PrihlasitSe_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            string helso = textBox2.Text;
            ConnectDB();
            if (Sing_on(login, helso))
            {
                if (Get_type_of_user().Equals("zakaznik"))
                {
                    this.Hide();
                    Uzivatel_ui a1 = new Uzivatel_ui();
                    a1.ShowDialog();
                }
                else if (Get_type_of_user().Equals("banker"))
                {
                    this.Hide();
                    Banker_ui b1 = new Banker_ui();
                    b1.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Neplatne prihlasovaci udaje!");
                }
                
            }

           
            
        }
       

        private void ZalozeniUctu_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Registrace_ui r1 = new Registrace_ui();
            r1.Show();
        }

    

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}