﻿using static BankApp.Osoby_metody;
using static BankApp.Ucty_metody;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BankApp
{
    public partial class SpravaUctu_ui : Form
    {
        public SpravaUctu_ui()
        {

            InitializeComponent();
            panel1.Hide();
            panel2.Hide();
            panel3.Hide();
        }
        public List<string> udaje = new List<string>();
        string cislo_op;
        string heslo;
        private void button1_Click(object sender, EventArgs e)
        {
          

            try
            {
                cislo_op = textBox1.Text;
                heslo = textBox2.Text;
                udaje = OsobaPresOpHeslo(cislo_op, heslo);
                MessageBox.Show(udaje.Count().ToString());
                panel1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Neplatné číslo OP nebo heslo.");
            }
        }
       
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Banker_ui u1 = new Banker_ui();
            u1.Show();
        }

        private void nastaveniToolStripMenuItem_Click(object sender, EventArgs e)
        {
          textBox3.Text = udaje[0];
          textBox4.Text = udaje[1];
          textBox5.Text = udaje[2];
          textBox6.Text = udaje[3];
          textBox7.Text = udaje[4];
          textBox8.Text= udaje[5];
          textBox10.Text= udaje[6];
          textBox9.Text = udaje[7];
          panel3.Hide();
          panel2.Show();

        }

        private void financeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label15.Text= udaje[9];
            label16.Text= udaje[8] + " Kč";
            panel2.Hide();
            panel3.Show();

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        List<string> noveUdaje = new List<string>();
        private void button2_Click(object sender, EventArgs e)
        {  
            noveUdaje.Add(textBox3.Text);//jmneo
            noveUdaje.Add(textBox4.Text);//prijmeni
            noveUdaje.Add(textBox6.Text);//email    
            noveUdaje.Add(textBox5.Text);//heslo
            noveUdaje.Add(textBox8.Text);//RC
            noveUdaje.Add(textBox7.Text);//COP
           
            string newUsername= textBox10.Text;
            string newHeslo = textBox9.Text;
            string cislo_uctu = udaje[9];
            try
            {
                UpdateOsoba(cislo_op, noveUdaje);
                UpdateUsernameHeslo(newUsername, newHeslo, cislo_uctu);
                MessageBox.Show("Udaje byly upraveny");
                
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Některý z upravovaných údajů nejspíše není ve správném formátu");
            } 
        }
    }
}
