﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using static BankApp.Pripojeni_db;
using static BankApp.Ucty_metody;

namespace BankApp
{
    internal class Kontokorent_metody
    {
        // Metoda pro aktualizaci hodnot v tabulce kontokorenty na základě atributu
        public static void Update_kontokorentValue(string newValue, string atribut)
        {
            try
            {
                SqlConnection cnn = ConnectDB(); // Připojení k databázi
                string id_uct = Get_id_uctu(get_login()); // Získání ID účtu přihlášeného uživatele
                string prikaz = "update kontokorenty set castka_kontok = " + newValue.ToString() + " where  vlastnik_kontok= " + id_uct + ";";
                string prikazB = "update kontokorenty set stav_kontok = '" + newValue.ToString() + "' where  vlastnik_kontok= " + id_uct + ";";
                string prikazC = "update kontokorenty set vycerpano_kontok = " + newValue.ToString() + " where  vlastnik_kontok= " + id_uct + ";";

                // Zkontroluje atribut a provede příslušný update na základě podmínky
                if (atribut == "castka_kontok")
                {
                    SqlCommand command = new SqlCommand(prikaz, cnn);
                    command.ExecuteNonQuery(); // Provádí aktualizaci hodnoty castka_kontok
                }
                else if (atribut == "stav_kontok")
                {
                    SqlCommand command = new SqlCommand(prikazB, cnn);
                    command.ExecuteNonQuery(); // Provádí aktualizaci hodnoty stav_kontok
                }
                else if (atribut == "vycerpano_kontok")
                {
                    SqlCommand command = new SqlCommand(prikazC, cnn);
                    command.ExecuteNonQuery(); // Provádí aktualizaci hodnoty vycerpano_kontok
                }

                cnn.Close(); // Uzavření připojení k databázi
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastala chyba v Update_kontokotenValue");
            }
        }

        // Metoda pro získání všech údajů o kontokorentu
        public static List<string> Get_kontokortentALL()
        {
            List<string> udaje = new List<string>();
            try
            {
                SqlConnection cnn = ConnectDB(); // Připojení k databázi


                // Dotaz pro získání všech údajů o kontokorente pro daného vlastníka
                string prikazB = "select * from kontokorenty where vlastnik_kontok =" + Get_id_uctu(get_login()) + ";";
                SqlCommand commandB = new SqlCommand(prikazB, cnn);

                // Čtení výsledků dotazu a přidání údajů do listu udaje
                using (SqlDataReader reader = commandB.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        udaje.Add(reader["id_kontok"].ToString());
                        udaje.Add(reader["vlastnik_kontok"].ToString());
                        udaje.Add(reader["stav_kontok"].ToString());
                        udaje.Add(reader["castka_kontok"].ToString());
                        udaje.Add(reader["vycerpano_kontok"].ToString());
                    }
                }
                return udaje; // Vrací seznam údajů o kontokorentu
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastala chyba v Get_kontokorent ALL");
                return udaje;
            }
        }
            
        }
    }

