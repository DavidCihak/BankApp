﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using static System.Windows.Forms.LinkLabel; // Importují se potřebné knihovny
using System.Data;

namespace BankApp
{
    internal class Pripojeni_db
    {
        // Statické proměnné pro uchování přihlašovacích údajů
        static string login_db;
        static string password_db;

        // Metoda pro získání typu uživatele na základě uživatelského jména a hesla
        public static string Get_type_of_user()
        {
            try { 
            SqlConnection cnn = ConnectDB(); // Připojení k databázi
            string typ_uziv = null; // Inicializace proměnné pro typ uživatele
            string prikaz_uziv = "select typ_uctu from ucty where username = '" + get_login() + "' and heslo = '" + get_heslo() + "';";
            SqlCommand uziv_command = new SqlCommand(prikaz_uziv, cnn); // Příkaz SQL pro získání typu uživatele

            using (SqlDataReader reader = uziv_command.ExecuteReader()) // Procházení výsledků dotazu
            {
                while (reader.Read())
                {
                    typ_uziv = reader["typ_uctu"].ToString(); // Uložení typu uživatele
                }
                cnn.Close(); // Uzavření spojení s databází
                return typ_uziv; // Vrácení typu uživatele
            }
            }
            catch (Exception e)
            {

                MessageBox.Show("Chyba Get_type_of_user");
                return null;
            }
        }

        // Metoda pro získání přihlašovacího jména
        public static string get_login()
        {
            return login_db;
        }

        // Metoda pro získání hesla
        public static string get_heslo()
        {
            return password_db;
        }

        // Metoda pro přihlášení uživatele s ověřením v databázi
        public static bool Sing_on(string log, string hes)
        {
            try
            {


                SqlConnection cnn = ConnectDB(); // Připojení k databázi
                Dictionary<string, string> login_heslo_db = new Dictionary<string, string>(); // Inicializace slovníku pro uživatelská jména a hesla
                string prikaz = "select username, heslo, typ_uctu from ucty where username = @log and heslo = @hes;";
                SqlCommand command = new SqlCommand(prikaz, cnn);
                command.Parameters.Add("@log", SqlDbType.NVarChar);
                command.Parameters.Add("@hes", SqlDbType.NVarChar);
                command.Parameters["@log"].Value = log; // Nastavení parametru uživatelského jména
                command.Parameters["@hes"].Value = hes; // Nastavení parametru hesla

                using (SqlDataReader reader = command.ExecuteReader()) // Procházení výsledků dotazu
                {
                    while (reader.Read())
                    {
                        login_db = reader["username"].ToString(); // Uložení přihlašovacího jména
                        password_db = reader["heslo"].ToString(); // Uložení hesla
                        login_heslo_db.Add(login_db, password_db);
                    }
                }

                if (login_heslo_db.Count < 1) // Pokud nebyly nalezeny shody neexistuje uzivatel se shodou
                {
                    MessageBox.Show("Spatny login nebo heslo");
                    return false; // Nepodařilo se přihlásit
                }
                else
                {
                    return true; // Podařilo se přihlásit resp. existuje uživatel se shodou
                }
            }catch(Exception ex)
            {
                return false;
                MessageBox.Show("wth?!");
                
            }
        }

        // Metoda pro rozdělení textu podle určených znaků
        public static string[] Split_date_others(string text)
        {
            char[] znaky = new char[] { '.', '=', ' ', '\t', ',', '-' };
            string[] rozdeleno = text.Split(znaky); // Rozdělení textu podle znaků
            return rozdeleno; // Vrácení výsledku rozdělení
        }

        // Metoda pro připojení k databázi
        public static SqlConnection ConnectDB()
        {
            string[] lines;
            try
            {
                string fileName = "DB_Udaje.txt";
                string path = Path.Combine(Environment.CurrentDirectory, @"Data\"); // Cesta k souboru s údaji pro databázi
                string pathB = Path.Combine(path, fileName);
                lines = System.IO.File.ReadAllLines(pathB); // Čtení údajů pro připojení z textového souboru
            }
            catch (FileNotFoundException e)
            {
                throw e;
            }
            List<string> udaje = new List<string>();
            for (int i = 0; i < 4; i++)
            {
                string[] udaj = Split_date_others(lines[i]); // Rozdělení jednotlivých údajů
                udaje.Add(udaj[1]); // Přidání údaje do seznamu
            }

            SqlConnection cnn;
            string connetionString;
            connetionString = @"Data Source=" + udaje[0] + ";Initial Catalog=" + udaje[1] + ";User ID=" + udaje[2] + ";Password=" + udaje[3] + ""; // Sestavení řetězce pro připojení k databázi
            cnn = new SqlConnection(connetionString);
            try
            {
                cnn.Open(); // Otevření spojení s databází
            }
            catch (Exception e)
            {
                Application.Exit(); // Ukončení aplikace v případě chyby připojení
            }

            return cnn; // Vrácení objektu pro práci s databází
        }

    }
}
