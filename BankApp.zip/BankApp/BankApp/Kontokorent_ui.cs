﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BankApp.Ucty_metody;
using static BankApp.Kontokorent_metody;

using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BankApp
{
    public partial class Kontokorent_ui : Form
    {
        List<string> kontokotentUdaje = new List<string>();
        public Kontokorent_ui()
        {
            InitializeComponent();
            kontokotentUdaje.Clear();
            kontokotentUdaje = Get_kontokortentALL();
            Kontokorent k1 = new Kontokorent(kontokotentUdaje[0], kontokotentUdaje[1], kontokotentUdaje[2], kontokotentUdaje[3], kontokotentUdaje[4]);
            label3.Text = k1.VycerpanoKontok;//pokud balance je 0 a kontokorent je zapnut, tak se hodnota odeslanych penez odečte z hodnoty kontoko¨rentu
            label8.Text = k1.CastkaKontok;
            comboBox1.Text = k1.StavKontoko;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Uzivatel_ui u1 = new Uzivatel_ui();
            u1.Show();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value < 1)
            {
                MessageBox.Show("Nelze nastavit méně než 1Kč");
            }
            else
            {
                Update_kontokorentValue(numericUpDown1.Value.ToString(), "castka_kontok");
                MessageBox.Show("Částka kontokorentu byla nastavena na " +numericUpDown1.Value.ToString());
            }
      
        }


        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Uzivatel_ui u1 = new Uzivatel_ui();
            u1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string status = comboBox1.Text;
            DialogResult dialogResult = MessageBox.Show("Opravdu si přejete "+status+ " kontokorent", "Potvrzení", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                
                Update_kontokorentValue(status, "stav_kontok");
                MessageBox.Show("Kontokorent "+status);
            }
            else if (dialogResult == DialogResult.No)
            {

            }
            
        }

        private void Kontokorent_ui_Load(object sender, EventArgs e)
        {

        }
    }
}
